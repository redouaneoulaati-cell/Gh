# Français au lycée – Maroc V8 — Android

Cette version conserve l'interface V7 et ajoute une préparation Android/PWA.

## Ajouts V8
- Mode Bac avec objectif de progression.
- Examen blanc (interface prête à relier aux questions Supabase).
- Indicateurs de révision, badges et temps d'étude.
- Indicateur en ligne/hors ligne.
- Service Worker pour un fonctionnement plus robuste hors connexion.
- Manifest installable.
- Structure Capacitor pour produire l'application Android.
- Identifiant Android : `ma.francaislycee.app`.

## Construire l'APK
### Build local
1. Installer Node.js et Android Studio/SDK.
2. `npm install`
3. `./prepare-web.sh`
4. `npm run android:add` (une seule fois)
5. `npm run android:sync`
6. `npm run android:build`

### Build automatique avec GitHub Actions
Le workflow `.github/workflows/build-apk.yml` prépare automatiquement `www`, ajoute la plateforme Android, synchronise Capacitor et construit l'APK debug. L'APK est disponible dans les **Artifacts** du workflow sous `Francais-au-lycee-Maroc-V8-debug-apk`.

Pour une version production, configurer une signature Android et les règles Supabase/RLS avant publication.

## Paiements
Ne jamais mettre de secret de paiement dans l'application. Les paiements réels doivent passer par un backend/fonction serveur et un prestataire compatible avec le Maroc.
