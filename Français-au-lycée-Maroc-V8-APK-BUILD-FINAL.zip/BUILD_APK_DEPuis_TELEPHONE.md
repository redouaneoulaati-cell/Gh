# Construire l'APK depuis un téléphone

1. Crée/connecte-toi à un compte GitHub.
2. Crée un nouveau dépôt (repository), par exemple `francais-lycee-maroc-v8`.
3. Téléverse le contenu de ce ZIP dans le dépôt et valide sur la branche `main`.
4. Ouvre l'onglet **Actions** du dépôt.
5. Choisis **Build Android APK**, puis **Run workflow**.
6. Attends la fin du workflow.
7. Dans le workflow terminé, ouvre **Artifacts** et télécharge :
   `Francais-au-lycee-Maroc-V8-debug-apk`
8. Décompresse l'archive téléchargée et installe `app-debug.apk` sur ton téléphone.

Remarque : il s'agit d'un APK debug pour test. Pour publier sur Google Play, il faudra ensuite générer une version signée (release) avec une clé de signature.
