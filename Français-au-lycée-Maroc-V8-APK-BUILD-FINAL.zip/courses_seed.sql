-- Catalogue initial « Français au lycée – Maroc »
-- Schéma attendu : courses(title, description, level, filiere, is_published)
-- Exécuter dans Supabase SQL Editor.

insert into public.courses (title, description, level, filiere, is_published) values
('Compréhension de texte : méthodes et stratégies','Identifier le thème, la thèse, les idées principales, les procédés et construire une réponse organisée.','Tronc commun','Français',true),
('Langue : classes grammaticales et fonctions','Révision des classes de mots, fonctions grammaticales et analyse de phrases.','Tronc commun','Français',true),
('Conjugaison et valeurs des temps','Maîtriser les temps verbaux et leurs valeurs dans les textes narratifs et argumentatifs.','Tronc commun','Français',true),
('Expression écrite : construire un paragraphe','Méthodes pour organiser les idées, utiliser les connecteurs et rédiger avec précision.','Tronc commun','Français',true),
('Communication et expression orale','Préparer une prise de parole, argumenter et présenter clairement une idée.','Tronc commun','Français',true),
('Vocabulaire et enrichissement lexical','Synonymes, antonymes, champs lexicaux, familles de mots et emploi précis du vocabulaire.','Tronc commun','Français',true),

('La nouvelle et le récit : analyser un texte','Étude des personnages, du point de vue, du temps, de l’espace et des procédés narratifs.','1er Bac','Français',true),
('La poésie : images et procédés','Comprendre les images poétiques, les figures de style, les sonorités et la construction du poème.','1er Bac','Français',true),
('Le théâtre : scène, personnages et dialogue','Lire une scène, analyser le dialogue théâtral et comprendre les enjeux de la représentation.','1er Bac','Français',true),
('Argumentation : convaincre et persuader','Identifier thèse, arguments, exemples et procédés de persuasion dans différents textes.','1er Bac','Français',true),
('Production écrite : texte argumentatif','Construire une introduction, développer des arguments et rédiger une conclusion efficace.','1er Bac','Français',true),
('Figures de style et procédés d’écriture','Métaphore, comparaison, personnification, antithèse, hyperbole et autres procédés essentiels.','1er Bac','Français',true),

('Roman et récit : lecture analytique','Méthode complète pour analyser un extrait narratif et construire une lecture organisée.','2e Bac','Français',true),
('Le théâtre : analyse d’une œuvre','Étude des personnages, conflits, didascalies, registres et enjeux dramaturgiques.','2e Bac','Français',true),
('La poésie : analyse et commentaire','Méthode d’analyse poétique et entraînement au commentaire composé.','2e Bac','Français',true),
('Argumentation et dissertation','Construire une problématique, un plan dialectique ou thématique et développer une argumentation.','2e Bac','Français',true),
('Commentaire composé : méthode du Bac','Méthode étape par étape pour analyser un texte et rédiger un commentaire structuré.','2e Bac','Français',true),
('Dissertation : méthode et entraînement','Comprendre le sujet, construire une problématique, organiser le plan et rédiger avec rigueur.','2e Bac','Français',true),
('Révision Bac : langue, figures et méthodologie','Synthèse des notions indispensables et entraînement aux principales compétences de l’examen.','2e Bac','Français',true);
