// Configuration Supabase
// La clé "publishable/anon" peut être utilisée côté navigateur.
// Ne placez JAMAIS une clé service_role dans ce fichier.

window.SUPABASE_URL = "https://ttlhpdlxsjvfhwfvhqfl.supabase.co";

// Remplacez la valeur ci-dessous par votre clé publishable/anon si nécessaire.
window.SUPABASE_ANON_KEY = "sb_publishable_JRh95RPfg2TpmSAa_E0y7g_6uG49KNA";
