# Français au lycée – Maroc V5

Interface professionnelle et responsive.

## Installation

1. Décompressez le ZIP.
2. Ouvrez `config.js`.
3. Gardez l'URL Supabase déjà indiquée.
4. Remplacez `REMPLACER_PAR_VOTRE_CLE_PUBLISHABLE` par votre clé publishable/anon.
5. Ouvrez `index.html` avec un serveur local ou publiez le dossier sur votre hébergement.

## Important

- Ne mettez jamais la clé `service_role` dans le navigateur.
- Cette version conserve vos tables Supabase existantes.
- Les noms de tables utilisés pour les statistiques sont `courses`, `exercises`, `ai_searches`, `downloads`. Si vos tables portent d'autres noms, modifiez-les dans `app.js`.
- L'interface IA est prête visuellement et enregistre les questions dans `ai_searches` lorsque la table et les politiques RLS l'autorisent.
- Les vrais paiements, téléchargements protégés, rôles admin/enseignant et réponses IA doivent être reliés à leurs fonctions/backend avant mise en production.

## Fichiers

- `index.html` : interface
- `styles.css` : design responsive
- `app.js` : navigation et logique Supabase
- `config.js` : configuration Supabase
- `README.md` : instructions

## Catalogue de français

La V5 contient un catalogue initial de 19 cours couvrant :
- Tronc commun : 6 cours
- 1er Bac : 6 cours
- 2e Bac : 7 cours

`courses_seed.sql` permet d'insérer ce catalogue dans la table `public.courses` existante. L'application charge ensuite les cours publiés depuis Supabase (`is_published = true`) et propose un catalogue local de secours si Supabase n'est pas encore accessible.
