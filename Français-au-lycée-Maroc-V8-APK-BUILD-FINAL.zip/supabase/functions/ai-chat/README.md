# Moteur IA

Déployer cette Edge Function puis définir le secret `OPENAI_API_KEY` dans Supabase.
Optionnel : `OPENAI_MODEL` pour choisir le modèle disponible sur votre compte.

La clé fournisseur reste côté serveur et n'est jamais placée dans `config.js`.
