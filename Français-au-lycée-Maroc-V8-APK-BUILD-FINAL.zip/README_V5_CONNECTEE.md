# Français au lycée – Maroc V6

## Fonctionnalités ajoutées
- Exercices interactifs avec corrections.
- Moteur IA via Supabase Edge Function `ai-chat`.
- Reconnaissance vocale pour poser une question à l'IA.
- Lecture vocale des réponses IA.
- Bibliothèque de 3 fiches PDF originales : Tronc commun, 1er Bac, 2e Bac.
- Discussions écrites avec Supabase Realtime.
- Messages vocaux avec MediaRecorder + Supabase Storage.

## Installation Supabase
1. Exécuter `supabase_setup.sql` dans SQL Editor.
2. Déployer `supabase/functions/ai-chat`.
3. Ajouter le secret serveur `OPENAI_API_KEY`.
4. Vérifier le bucket Storage `voice-messages`.
5. Pour héberger les PDF dans Supabase Storage, créer un bucket `books` et y téléverser les fichiers du dossier `books/`.

## Sécurité
La clé publishable/anon peut rester dans `config.js`. Ne jamais mettre `service_role` ni la clé fournisseur IA dans le navigateur.

## Lives et vidéos
- Les enseignants peuvent programmer des réunions depuis « Lives & vidéos ».
- Chaque réunion reçoit une salle dédiée et les élèves peuvent la rejoindre.
- Les vidéos pédagogiques sont chargées depuis `lesson_videos`.
- Le projet utilise une salle Jitsi intégrée pour la visioconférence. Vérifie les conditions du service avant un déploiement public.
